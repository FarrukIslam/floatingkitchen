<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


if(!class_exists('FPD_Order')) {

	class FPD_Order {

		public function __construct() {

			add_action( 'woocommerce_add_order_item_meta', array( &$this, 'add_order_item_meta'), 10, 2 );

			//edit order item permalink, so it loads the customized product
			add_filter( 'woocommerce_order_item_permalink', array(&$this, 'change_order_item_permalink') , 10, 3 );

			//add additional links to order item
			add_action( 'woocommerce_order_item_meta_end', array(&$this, 'add_order_item_links') , 10, 3 );

		}

		//add order meta from the cart
		public function add_order_item_meta( $item_id, $values ) {

			if( isset( $values['fpd_data']) ) {
				woocommerce_add_order_item_meta( $item_id, 'fpd_data', $values['fpd_data'] );
			}

		}

		public function change_order_item_permalink( $permalink, $item, $order ) {

			if(isset($item['fpd_data'])) {

				$order_items = $order->get_items();
				$item_id = array_search($item, $order_items);

				if($item_id !== false) {
					$permalink = add_query_arg( array('order' => $order->id, 'item_id' => $item_id), $permalink );
				}
			}

			return $permalink;

		}

		public function add_order_item_links( $item_id, $item, $order ) {

			$product = $order->get_product_from_item( $item );

			//download button
			if( isset($item['fpd_data']) &&  $product->is_downloadable() && $order->is_download_permitted() ) {

				$url = add_query_arg( array('order' => $order->id, 'item_id' => $item_id), $product->get_permalink() );

				echo '<a href="'.esc_url( $url ).'" class="fpd-order-item-download" style="font-size: 0.85em;">Download</a>' ;
			}

			//view customized product link
			if( isset($item['fpd_data']) ) {

				$url = add_query_arg( array('order' => $order->id, 'item_id' => $item_id), $product->get_permalink() );
				echo sprintf( '<a href="%s" style="display: block;font-size: 0.9em;">%s</a>', $url, FPD_Settings_Labels::get_translation('misc', 'woocommerce_order:_email_view_customized_product') );

			}


		}

	}
}

new FPD_Order();

?>