<?php

global $gema75_wc_wishlist;


//start framework
$option = new Gema75_input_boxes();


//enqueue color pickers
wp_enqueue_script('wp-color-picker');
wp_enqueue_style( 'wp-color-picker' );

//enqueue image upload scripts
wp_enqueue_script( 'gema75_wc_wl-image-upload',untrailingslashit( plugins_url( '/', __FILE__ ) ).'/includes/image_upload.js' ,array( 'jquery', 'media-upload', 'thickbox' ) );
wp_enqueue_style( 'thickbox' );



//save admin options on submit
if(isset($_POST['gema75_wc_wl_submit'])) {

	$gema75_wc_wishlist->save_admin_options();
}

//get saved options 
$gema75_wc_wl_options = $gema75_wc_wishlist->get_admin_saved_options()	;

//print_r($gema75_wc_wl_options);

?>

<script type="text/javascript">
	jQuery(document).ready(function($) {
        $('#wishlist_bg_color').wpColorPicker({
        	color: true,
        });
	});
</script>

<div class="wrap" style="background-color: #fff;padding: 20px;">
	<h2>Wishlist Options</h2>

	<form method="post" >
		<table class="form-table">
		
		
			<tr valign="top">
				<th scope="row">Show on single product page </th>
				<td  colspan="3">
	
					<?php	
					$boxi = array(
						'type' => 'select',
						'std' => $gema75_wc_wl_options['show_link_on_single_page'],
						'id'=>'show_on_single_page',
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Show "Add to wishlist" on single product page '
					);
					
					$option->input($boxi);

					?>

				</td>
			</tr>
			
			<tr valign="top">
				<th scope="row">Show on shop page </th>
				<td  colspan="3">
	
					<?php	
					$boxi2 = array(
						'type' => 'select',
						'id' => 'show_on_shop_page',
						'std' => $gema75_wc_wl_options['show_link_on_shop_page'],
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Show "Add to wishlist" on shop category page '
					);

					$option->input($boxi2);
					?>

				</td>
			</tr>
		
			<tr valign="top">
				<th scope="row">Wishlist position </th>
				<td  colspan="3">
					<?php	
					$boxi_position = array(
						'type' => 'select',
						'id' => 'wishlist_position',
						'std' => $gema75_wc_wl_options['wishlist_position'],
						'options' => array('top'=>'Top','bottom'=>'Bottom'),
						'description' => 'Position of the wishlist container '
					);

					$option->input($boxi_position);
					?>					
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">Open wishlist when </th>
				<td  colspan="3">
					<?php	
					$boxi_open_with = array(
						'type' => 'select',
						'id' => 'open_wishlist_when',
						'std' => $gema75_wc_wl_options['open_wishlist_when'],
						'options' => array('click'=>'Clicked','hover'=>'Mouse Over'),
						'description' => 'Open the wishlist when clicked or mouse is over '
					);

					$option->input($boxi_open_with);
					?>					
				</td>
			</tr>		

			<tr valign="top">
				<th scope="row">Tab text or Image </th>
				<td  colspan="3">
					<?php	
					$boxi_wishlist_use_text_or_image_for_slideout_tab = array(
						'type' => 'select',
						'id' => 'wishlist_use_text_or_image_for_slideout_tab',
						'std' => $gema75_wc_wl_options['wishlist_use_text_or_image_for_slideout_tab'],
						'options' => array('text'=>'Text','image'=>'Image'),
						'description' => 'Use text or an image for the slide tab'
					);

					$option->input($boxi_wishlist_use_text_or_image_for_slideout_tab);
					?>					
				</td>
			</tr>			



			<tr valign="top">
				<th scope="row">Panel Width (%)</th>
				<td  colspan="3">
					<?php	
					$boxi_wishlist_panel_width = array(
						'type' => 'text',
						'id' => 'wishlist_panel_width_in_percent',
						'std' => $gema75_wc_wl_options['wishlist_panel_width_in_percent'],
						'description' => 'Panel width in percentage . Write only the number  i.e 60 ... 70  ... 90'
					);

					$option->input($boxi_wishlist_panel_width);
					?>					
				</td>
			</tr>			

			
			<tr valign="top">
				<th scope="row">Margin Left/Right (%)</th>
				<td  colspan="3">
					<?php	
					$boxi_wishlist_panel_margin = array(
						'type' => 'text',
						'id' => 'wishlist_panel_margin_in_percent',
						'std' => $gema75_wc_wl_options['wishlist_panel_margin_in_percent'],
						'description' => 'Panel margin in percentage . Write only the number  i.e 5...6...7...10'
					);

					$option->input($boxi_wishlist_panel_margin);
					?>					
				</td>
			</tr>			

			<tr valign="top">
				<th scope="row"><h3> Text customization </h3>	 </th>
				<td  colspan="3">&nbsp;</td>
			</tr>			
			
			<tr valign="top">
				<th scope="row">Wishlist Tab Text </th>
				<td  colspan="3">
					<?php	
					$boxi_wishlist_tab_header_text = array(
						'type' => 'text',
						'id' => 'wishlist_slider_tab_header',
						'std' => $gema75_wc_wl_options['wishlist_slider_tab_header'],
						'description' => 'Wishlist tab text'
					);

					$option->input($boxi_wishlist_tab_header_text);
					?>					
				</td>
			</tr>	
			
			
			<tr valign="top">
				<th scope="row">Wishlist Tab Image </th>
				<td  colspan="3">
					<?php	
					$boxi_wishlist_tab_header_image = array(
						'type' => 'upload',
						'id' => 'wishlist_slider_tab_image',
						'std' => $gema75_wc_wl_options['wishlist_slider_tab_image'],
						'description' => 'Wishlist tab image'
					);

					$option->input($boxi_wishlist_tab_header_image);
					?>	
					
					<div id="wishlist_slider_tab_image_preview"></div>
				</td>
			</tr>			

			<tr valign="top">
				<th scope="row">"Add to Wishlist" Text </th>
				<td  colspan="3">
					<?php	
					$boxi_add_to_wishlist_text = array(
						'type' => 'text',
						'id' => 'add_to_wishlist_text',
						'std' => $gema75_wc_wl_options['add_to_wishlist_text'],
						'description' => 'Customize "Add to wishlist" text'
					);

					$option->input($boxi_add_to_wishlist_text);
					?>					
				</td>
			</tr>		

			<tr valign="top">
				<th scope="row">"Already on wishlist" Text </th>
				<td  colspan="3">
					<?php	
					$boxi_already_on_wishlist_text = array(
						'type' => 'text',
						'id' => 'already_on_wishlist_text',
						'std' => $gema75_wc_wl_options['already_on_wishlist_text'],
						'description' => 'Customize "Already on wishlist" text'
					);

					$option->input($boxi_already_on_wishlist_text);
					?>					
				</td>
			</tr>			
			
			<tr valign="top">
				<th scope="row">"Remove from wishlist" Text </th>
				<td  colspan="3">
					<?php	
					$boxi_remove_from_wishlist_text = array(
						'type' => 'text',
						'id' => 'remove_from_wishlist_text',
						'std' => $gema75_wc_wl_options['remove_from_wishlist_text'],
						'description' => 'Customize "Remove from wishlist" text'
					);

					$option->input($boxi_remove_from_wishlist_text);
					?>					
				</td>
			</tr>
			
			
			<tr valign="top">
				<th scope="row">"Remove all from wishlist" Text </th>
				<td  colspan="3">
					<?php	
					$boxi_remove_all_from_wishlist_text = array(
						'type' => 'text',
						'id' => 'remove_all_from_wishlist_text',
						'std' => $gema75_wc_wl_options['remove_all_from_wishlist_text'],
						'description' => 'Customize "Remove all from wishlist" text'
					);

					$option->input($boxi_remove_all_from_wishlist_text);
					?>					
				</td>
			</tr>			
			
			<tr valign="top">
				<th scope="row">"Added to wishlist" Text </th>
				<td  colspan="3">
					<?php	
					$boxi_added_to_wishlist_text = array(
						'type' => 'text',
						'id' => 'added_to_wishlist_text',
						'std' => $gema75_wc_wl_options['added_to_wishlist_text'],
						'description' => 'Customize "Added to wishlist" text'
					);

					$option->input($boxi_added_to_wishlist_text);
					?>					
				</td>
			</tr>
			
			<tr valign="top">
				<th scope="row">"Add to cart" Text </th>
				<td  colspan="3">
					<?php	
					$boxi_add_to_cart_text = array(
						'type' => 'text',
						'id' => 'add_to_cart_text',
						'std' => $gema75_wc_wl_options['add_to_cart_text'],
						'description' => 'Customize "Add to cart" text'
					);

					$option->input($boxi_add_to_cart_text);
					?>					
				</td>
			</tr>
			
			
			<tr valign="top">
				<th scope="row">Wishlist Counter </th>
				<td  colspan="3">
					<?php	
					$boxi_wishlist_tab_header_counter = array(
						'type' => 'select',
						'id' => 'wishlist_slider_tab_header_show_counter',
						'std' => $gema75_wc_wl_options['wishlist_slider_tab_header_show_counter'],
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Show numeric counter on the wishlist tab '
					);
					$option->input($boxi_wishlist_tab_header_counter);
					?>					
				</td>
			</tr>				
			
			<tr valign="top">
				<th scope="row">Background color </th>
				<td  colspan="3">
					<?php
					$boxi_bg_color = array(
						'type' => 'colorpicker',
						'id' => 'wishlist_bg_color',
						'std' => $gema75_wc_wl_options['wishlist_bg_color'],
						'description' => 'Slideout background color '
					);

					$option->input($boxi_bg_color);		
					?>					
				</td>
			</tr>	


			<tr valign="top">
				<th scope="row"><h3>Social Share </h3>	 </th>
				<td  colspan="3">&nbsp;</td>
			</tr>

			<tr valign="top">
				<th scope="row">Image URL</th>
				<td  colspan="3">
					<?php	
					$boxi_social_share_logo_url = array(
						'type' => 'text',
						'id' => 'social_share_logo_url',
						'std' => $gema75_wc_wl_options['social_share_logo_url'],
						'description' => 'URL of an image or website logo to be used for Facebook and Pinterest sharing'
					);
					$option->input($boxi_social_share_logo_url);
					?>
				</td>
			</tr>			
			
			<tr valign="top">
				<th scope="row">Facebook Share</th>
				<td  colspan="3">
					<?php	
					$boxi_allow_sharing_on_facebook = array(
						'type' => 'select',
						'id' => 'allow_sharing_on_facebook',
						'std' => $gema75_wc_wl_options['allow_sharing_on_facebook'],
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Allow wishlist to be shared on Facebook '
					);
					$option->input($boxi_allow_sharing_on_facebook);
					?>
				</td>
			</tr>			

			<tr valign="top">
				<th scope="row">&nbsp; </th>
				<td  colspan="3">
					<?php
					$boxi_social_share_facebook_text = array(
						'type' => 'textarea',
						'id' => 'social_share_facebook_text',
						'std' => $gema75_wc_wl_options['social_share_facebook_text'],
						'description' => 'Predefined Facebook message. Used as OG:Meta description'
					);
					$option->input($boxi_social_share_facebook_text);
					?>					
				</td>
			</tr>			

			
			<tr valign="top">
				<th scope="row">Twitter Share </th>
				<td  colspan="3">
					<?php
					$boxi_allow_sharing_on_twitter = array(
						'type' => 'select',
						'id' => 'allow_sharing_on_twitter',
						'std' => $gema75_wc_wl_options['allow_sharing_on_twitter'],
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Allow wishlist to be shared on Twitter'
					);
					$option->input($boxi_allow_sharing_on_twitter);
					?>					
				</td>
			</tr>	
			<tr valign="top">
				<th scope="row">&nbsp; </th>
				<td  colspan="3">
					<?php
					$boxi_social_share_twitter_text = array(
						'type' => 'textarea',
						'id' => 'social_share_twitter_text',
						'std' => $gema75_wc_wl_options['social_share_twitter_text'],
						'description' => 'Predefined twitter status message. The URL of the wishlist will be appended last '
					);
					$option->input($boxi_social_share_twitter_text);
					?>					
				</td>
			</tr>	


			<tr valign="top">
				<th scope="row">Pinterest Share </th>
				<td  colspan="3">
					<?php
					$boxi_allow_sharing_on_pinterest = array(
						'type' => 'select',
						'id' => 'allow_sharing_on_pinterest',
						'std' => $gema75_wc_wl_options['allow_sharing_on_pinterest'],
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Allow wishlist to be shared on Pinterest'
					);
					$option->input($boxi_allow_sharing_on_pinterest);
					?>					
				</td>
			</tr>	
			<tr valign="top">
				<th scope="row">&nbsp; </th>
				<td  colspan="3">
					<?php
					$boxi_social_share_pinterest_text = array(
						'type' => 'textarea',
						'id' => 'social_share_pinterest_text',
						'std' => $gema75_wc_wl_options['social_share_pinterest_text'],
						'description' => 'Predefined pinterest status message'
					);
					$option->input($boxi_social_share_pinterest_text);
					?>					
				</td>
			</tr>

			<tr valign="top">
				<th scope="row">Google+ Share</th>
				<td  colspan="3">
					<?php	
					$boxi_allow_sharing_on_googleplus = array(
						'type' => 'select',
						'id' => 'allow_sharing_on_googleplus',
						'std' => $gema75_wc_wl_options['allow_sharing_on_googleplus'],
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Allow wishlist to be shared on Google+ '
					);
					$option->input($boxi_allow_sharing_on_googleplus);
					?>
				</td>
			</tr>			

			<tr valign="top">
				<th scope="row">Email to a friend</th>
				<td  colspan="3">
					<?php
					$boxi_allow_sharing_via_email = array(
						'type' => 'select',
						'id' => 'allow_sharing_on_email',
						'std' => $gema75_wc_wl_options['allow_sharing_on_email'],
						'options' => array('yes'=>'Yes','no'=>'No'),
						'description' => 'Allow wishlist to be shared via Email'
					);
					$option->input($boxi_allow_sharing_via_email);
					?>					
				</td>
			</tr>	
			<tr valign="top">
				<th scope="row">&nbsp; </th>
				<td  colspan="3">
					<?php
					$boxi_social_share_email_subject_text = array(
						'type' => 'text',
						'id' => 'social_share_email_subject_text',
						'std' => $gema75_wc_wl_options['social_share_email_subject_text'],
						'description' => 'Predefined email subject message'
					);
					$option->input($boxi_social_share_email_subject_text);
					?>					
				</td>
			</tr>		
			<tr valign="top">
				<th scope="row">&nbsp; </th>
				<td  colspan="3">
					<?php
					$boxi_social_share_email_message_body_text = array(
						'type' => 'textarea',
						'id' => 'social_share_email_body_text',
						'std' => $gema75_wc_wl_options['social_share_email_body_text'],
						'description' => 'Predefined email body message'
					);
					$option->input($boxi_social_share_email_message_body_text);
					?>					
				</td>
			</tr>

			<tr>
				<td>
					<input type="submit" name="gema75_wc_wl_submit" value="Save Changes">
				</td>
			</tr>
		</table>
	</form>			
</div>