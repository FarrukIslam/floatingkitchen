<?php
/*
Plugin Name: Woocommerce Wish List
Plugin URI: http://codecanyon.net/user/Gema75/portfolio
Description: Creates a Wishlist For the Woocommerce 
Version: 2.0
Author: Gema75
Author URI: http://codecanyon.net/user/Gema75
*/



if (!class_exists('Gema75_Woocommerce_Wishlist')) {

	class Gema75_Woocommerce_Wishlist {

		public $wc_active =false;

		public $show_link_on_shop_page = 'no';

		public $show_link_on_single_page = 'no';
		
		public $wishlist_position = 'top';
		
		//text of the slideout tab
		public $wishlist_slider_tab_header = 'Wishlist';
		
		//image of the slideout tab 
		public $wishlist_slider_tab_image ='';
		
		//image of the slideout tab 
		public $wishlist_slider_tab_image_width ='';

		//image of the slideout tab 
		public $wishlist_slider_tab_image_height ='';		
		
		//use text or image for the slideout tab
		public $wishlist_use_text_or_image_for_slideout_tab = 'text';
		
		//panel width in percentage
		public $wishlist_panel_width_in_percent = '80';
		
		//panel margin in percent
		public $wishlist_panel_margin_in_percent = '5';
		
		
		//"add to wishlist" text
		public $add_to_wishlist_text = 'Add to wishlist';
		
		//"added to wishlist" text
		public $added_to_wishlist_text = 'Added to wishlist';
		
		//"already on wishlist" text
		public $already_on_wishlist_text = 'Already on Wishlist';
		
		//"add to cart" text
		public $add_to_cart_text = 'Add to cart';
		
		//"remove" from wishlist
		public $remove_from_wishlist_text = 'Remove';		
		
		//"remove all" from wishlist
		public $remove_all_from_wishlist_text = 'Remove all';
		
		//show counter of how many products on wishlist tab
		public $wishlist_slider_tab_header_show_counter = 'yes';
		
		//open wishlist when clicked or hover
		public $open_wishlist_when = 'click';
		
		//wishlist bg color
		public $wishlist_bg_color= '#dd3333';
		
		//facebook share 
		public $allow_sharing_on_facebook = 'yes';
		
		//facebook description
		public $social_share_facebook_text='Facebook share text description';
		
		//twitter share 
		public $allow_sharing_on_twitter = 'yes';
		
		//text for the twitt
		public $social_share_twitter_text = 'Look what i found for twitter';

		//pinterest share
		public $allow_sharing_on_pinterest = 'yes';
		
		//text for pinterest
		public $social_share_pinterest_text = 'Text for pinterest';

		//pinterest share
		public $allow_sharing_on_googleplus = 'yes';		
		
		//image or logo url for social share . to be used as banner of OG:IMAGE and Pinterest
		public $social_share_logo_url='';

		//email share
		public $allow_sharing_on_email = 'yes';
		
		//text for email subject
		public $social_share_email_subject_text = 'Text for email subject';

		//text for email message body
		public $social_share_email_body_text = 'Text for email message body';	

		

		function __construct(){
			
			define( 'GEMA75_WC_WISHLIST_PLUGIN_URL', untrailingslashit( plugins_url( '/', __FILE__ ) ) );
			define( 'GEMA75_WC_WISHLIST_PLUGIN_DIR', plugin_dir_path(__FILE__) );
			

			//add admin menu
			add_action( 'admin_menu', array($this,'add_admin_menu') );	

			//hook for our social share templates
			add_action('template_redirect',  array($this,'my_url_handler') );	
			add_filter('init',  array($this,'social_rewrite_rules'));
			
	 		$get_saved_options = get_option('gema75_wc_wl_saved_admin_options',true);

			//add default options on plugin activation
			if(!isset($get_saved_options['first_time_installation'])) {
				register_activation_hook( __FILE__, array( $this, 'add_default_options_first_time' ) );
			}


			$this->is_wc_active();

		}
		
		
		function add_admin_menu(){
			add_menu_page( 'WC Wishlist', 'Wc Wishlist','manage_options', 'gema_wc_wl_settings',array( $this, 'show_options_page' ) );
		}	

		
		function show_options_page(){
		
			//include inputs framework
			require_once( GEMA75_WC_WISHLIST_PLUGIN_DIR . 'gema75.input.boxes.class.php');

			//open page
			require_once( GEMA75_WC_WISHLIST_PLUGIN_DIR . 'admin_options.php');

		}	



		function enqueue_scripts_and_styles(){
				//load slideout assets
				wp_enqueue_script( 'tabslideout-jquery',GEMA75_WC_WISHLIST_PLUGIN_URL.'/includes/slidein/jquery.tabslideout.js',array( 'jquery'), '1.3.0', true );
				wp_enqueue_style( 'tabslideout-css',GEMA75_WC_WISHLIST_PLUGIN_URL.'/includes/slidein/tabslideout.css' );
				

				//load owl carousel assets
				wp_enqueue_script( 'owlcarousel-jquery',GEMA75_WC_WISHLIST_PLUGIN_URL.'/includes/owncarousel/owl.carousel.min.js',array( 'jquery'), '1.3.0', true );
				wp_enqueue_style( 'owlcarousel-css',GEMA75_WC_WISHLIST_PLUGIN_URL.'/includes/owncarousel/owl.carousel.css' );
				wp_enqueue_style( 'owlcarousel-theme-css',GEMA75_WC_WISHLIST_PLUGIN_URL.'/includes/owncarousel/owl.theme.css' );
				
				//load our own style
				wp_enqueue_style( 'gema75-style-css',GEMA75_WC_WISHLIST_PLUGIN_URL.'/styles.css' );
				
				//scripts
				wp_enqueue_script( 'fo-scripts-jquery',GEMA75_WC_WISHLIST_PLUGIN_URL.'/includes/scripts.js',array( 'jquery'), '1.3.0', true );
				
				//localize Javascript
				wp_localize_script( 'fo-scripts-jquery', 'gema75_wc_wl_js_strings',$this->localize_js() );
				
		}
		
		
		function localize_js() {
		
	
		
			return array(
				'AlreadyExists' 				=> $this->already_on_wishlist_text,
				'removeFromWishlist' 			=> $this->remove_from_wishlist_text,
				'addedToWishlist' 				=> $this->added_to_wishlist_text,
				'addToCart' 					=> $this->add_to_cart_text,
				'position'						=> $this->wishlist_position,
				'open_wishlist_with'			=> $this->open_wishlist_when,
				'wishlist_bg_color'				=> $this->wishlist_bg_color,
				'wishlist_tab_text_or_image'	=> $this->wishlist_use_text_or_image_for_slideout_tab,
				'slider_tab_image_url'			=> $this->wishlist_slider_tab_image,
				'slider_tab_image_height'		=> $this->wishlist_slider_tab_image_width,
				'slider_tab_image_width'		=> $this->wishlist_slider_tab_image_height,
			);
		}

		function get_admin_saved_options(){

			$saved_options = get_option('gema75_wc_wl_saved_admin_options',true);


			if($saved_options['show_link_on_single_page'] === 'yes'){
				$this->show_link_on_single_page = 'yes' ;
				
			}

			if($saved_options['show_link_on_shop_page']==='yes'){
				$this->show_link_on_shop_page = 'yes' ;
			}

			if(isset($saved_options['wishlist_position'])){
				$this->wishlist_position = $saved_options['wishlist_position'] ;
			}	

			if(isset($saved_options['wishlist_slider_tab_header'])){
				$this->wishlist_slider_tab_header = $saved_options['wishlist_slider_tab_header'] ;
			}	

			if(isset($saved_options['wishlist_panel_width_in_percent'])){
				$this->wishlist_panel_width_in_percent = $saved_options['wishlist_panel_width_in_percent'] ;
			}			
			
			if(isset($saved_options['wishlist_panel_margin_in_percent'])){
				$this->wishlist_panel_margin_in_percent = $saved_options['wishlist_panel_margin_in_percent'] ;
			}				
			
			
			if(isset($saved_options['add_to_wishlist_text'])){
				$this->add_to_wishlist_text = $saved_options['add_to_wishlist_text'] ;
			}
			
			if(isset($saved_options['added_to_wishlist_text'])){
				$this->added_to_wishlist_text = $saved_options['added_to_wishlist_text'] ;
			}			
	
			
			if(isset($saved_options['already_on_wishlist_text'])){
				$this->already_on_wishlist_text = $saved_options['already_on_wishlist_text'] ;
			}			
			
			if(isset($saved_options['remove_from_wishlist_text'])){
				$this->remove_from_wishlist_text = $saved_options['remove_from_wishlist_text'] ;
			}			
			
			if(isset($saved_options['remove_all_from_wishlist_text'])){
				$this->remove_all_from_wishlist_text = $saved_options['remove_all_from_wishlist_text'] ;
			}			
			
			if(isset($saved_options['add_to_cart_text'])){
				$this->add_to_cart_text = $saved_options['add_to_cart_text'] ;
			}			
			

			if(isset($saved_options['wishlist_slider_tab_image'])){
				$this->wishlist_slider_tab_image = $saved_options['wishlist_slider_tab_image'] ;
			}			
			
			if(isset($saved_options['image_handler_width'])){
				$this->wishlist_slider_tab_image_width = $saved_options['image_handler_width'] ;
			}			
			
			if(isset($saved_options['image_handler_height'])){
				$this->wishlist_slider_tab_image_height = $saved_options['image_handler_height'] ;
			}
		
			
			if(isset($saved_options['wishlist_use_text_or_image_for_slideout_tab'])){
				$this->wishlist_use_text_or_image_for_slideout_tab = $saved_options['wishlist_use_text_or_image_for_slideout_tab'] ;
			}			
			

			if(isset($saved_options['wishlist_slider_tab_header_show_counter'])){
				$this->wishlist_slider_tab_header_show_counter = $saved_options['wishlist_slider_tab_header_show_counter'] ;
			}			
			
			if(isset($saved_options['open_wishlist_when'])){
				$this->open_wishlist_when = $saved_options['open_wishlist_when'] ;
			}
	
			if(isset($saved_options['wishlist_bg_color'])){
				$this->wishlist_bg_color = $saved_options['wishlist_bg_color'] ;
			}	
			
			if(isset($saved_options['allow_sharing_on_facebook'])){
				$this->allow_sharing_on_facebook = $saved_options['allow_sharing_on_facebook'] ;
			}			
			
			if(isset($saved_options['social_share_facebook_text'])){
				$this->social_share_facebook_text = $saved_options['social_share_facebook_text'] ;
			}		

			if(isset($saved_options['allow_sharing_on_twitter'])){
				$this->allow_sharing_on_twitter = $saved_options['allow_sharing_on_twitter'] ;
			}
			
			if(isset($saved_options['social_share_twitter_text'])){
				$this->social_share_twitter_text = $saved_options['social_share_twitter_text'] ;
			}			

			if(isset($saved_options['allow_sharing_on_pinterest'])){
				$this->allow_sharing_on_pinterest = $saved_options['allow_sharing_on_pinterest'] ;
			}

			if(isset($saved_options['social_share_pinterest_text'])){
				$this->social_share_pinterest_text = $saved_options['social_share_pinterest_text'] ;
			}			
			
			if(isset($saved_options['allow_sharing_on_googleplus'])){
				$this->allow_sharing_on_googleplus = $saved_options['allow_sharing_on_googleplus'] ;
			}			
			
			if(isset($saved_options['social_share_logo_url'])){
				$this->social_share_logo_url = $saved_options['social_share_logo_url'] ;
			}			

			
			if(isset($saved_options['allow_sharing_on_email'])){
				$this->allow_sharing_on_email = $saved_options['allow_sharing_on_email'] ;
			}
			if(isset($saved_options['social_share_email_subject_text'])){
				$this->social_share_email_subject_text = $saved_options['social_share_email_subject_text'] ;
			}	
			if(isset($saved_options['social_share_email_body_text'])){
				$this->social_share_email_body_text = $saved_options['social_share_email_body_text'] ;
			}			

		

			return $saved_options;


		}


		function save_admin_options(){

			$opts_array = array();

			$opts_array['show_link_on_single_page'] = (isset($_POST['show_on_single_page'])) ? sanitize_text_field($_POST['show_on_single_page']) : 'no';
			$opts_array['show_link_on_shop_page']   = (isset($_POST['show_on_shop_page'])) ? sanitize_text_field($_POST['show_on_shop_page']) : 'no';
			$opts_array['wishlist_position']   = (isset($_POST['wishlist_position'])) ? sanitize_text_field($_POST['wishlist_position']) : 'bottom';
			$opts_array['wishlist_slider_tab_header']   = (isset($_POST['wishlist_slider_tab_header'])) ? sanitize_text_field($_POST['wishlist_slider_tab_header']) : 'Wishlist';
			$opts_array['add_to_wishlist_text']   = (isset($_POST['add_to_wishlist_text'])) ? sanitize_text_field($_POST['add_to_wishlist_text']) : 'Add to wishlist';
			$opts_array['added_to_wishlist_text']   = (isset($_POST['added_to_wishlist_text'])) ? sanitize_text_field($_POST['added_to_wishlist_text']) : 'Added to wishlist';
			$opts_array['already_on_wishlist_text']   = (isset($_POST['already_on_wishlist_text'])) ? sanitize_text_field($_POST['already_on_wishlist_text']) : 'Already on wishlist';
			$opts_array['remove_from_wishlist_text']   = (isset($_POST['remove_from_wishlist_text'])) ? sanitize_text_field($_POST['remove_from_wishlist_text']) : 'Remove';
			$opts_array['remove_all_from_wishlist_text']   = (isset($_POST['remove_all_from_wishlist_text'])) ? sanitize_text_field($_POST['remove_all_from_wishlist_text']) : 'Remove all';
			$opts_array['add_to_cart_text']   = (isset($_POST['add_to_cart_text'])) ? sanitize_text_field($_POST['add_to_cart_text']) : 'Add to cart';
			
			$opts_array['wishlist_slider_tab_image']   = (isset($_POST['wishlist_slider_tab_image'])) ? sanitize_text_field($_POST['wishlist_slider_tab_image']) : '';
			
			$opts_array['wishlist_use_text_or_image_for_slideout_tab']   = (isset($_POST['wishlist_use_text_or_image_for_slideout_tab'])) ? sanitize_text_field($_POST['wishlist_use_text_or_image_for_slideout_tab']) : 'text';
			
			$opts_array['wishlist_panel_width_in_percent']   = (isset($_POST['wishlist_panel_width_in_percent'])) ? sanitize_text_field($_POST['wishlist_panel_width_in_percent']) : '80';
			
			$opts_array['wishlist_panel_margin_in_percent']   = (isset($_POST['wishlist_panel_margin_in_percent'])) ? sanitize_text_field($_POST['wishlist_panel_margin_in_percent']) : '5';
			
			
			
			
			$opts_array['wishlist_slider_tab_header_show_counter']   = (isset($_POST['wishlist_slider_tab_header_show_counter'])) ? sanitize_text_field($_POST['wishlist_slider_tab_header_show_counter']) : 'yes';
			$opts_array['open_wishlist_when']   = (isset($_POST['open_wishlist_when'])) ? sanitize_text_field($_POST['open_wishlist_when']) : 'click';
			$opts_array['wishlist_bg_color']   = (isset($_POST['wishlist_bg_color'])) ? sanitize_text_field($_POST['wishlist_bg_color']) : '#dd3333';
			
			$opts_array['allow_sharing_on_facebook']   = (isset($_POST['allow_sharing_on_facebook'])) ? sanitize_text_field($_POST['allow_sharing_on_facebook']) : 'yes';
			$opts_array['social_share_facebook_text']   = (isset($_POST['social_share_facebook_text'])) ? sanitize_text_field($_POST['social_share_facebook_text']) : 'Facebook share text description';
			$opts_array['allow_sharing_on_twitter']   = (isset($_POST['allow_sharing_on_twitter'])) ? sanitize_text_field($_POST['allow_sharing_on_twitter']) : 'yes';
			$opts_array['social_share_twitter_text']   = (isset($_POST['social_share_twitter_text'])) ? sanitize_text_field($_POST['social_share_twitter_text']) : 'Look what i found for twitter';
		
			$opts_array['allow_sharing_on_pinterest']   = (isset($_POST['allow_sharing_on_pinterest'])) ? sanitize_text_field($_POST['allow_sharing_on_pinterest']) : 'yes';
			$opts_array['social_share_pinterest_text']   = (isset($_POST['social_share_pinterest_text'])) ? sanitize_text_field($_POST['social_share_pinterest_text']) : 'Text for pinterest';
			
			$opts_array['allow_sharing_on_googleplus']   = (isset($_POST['allow_sharing_on_googleplus'])) ? sanitize_text_field($_POST['allow_sharing_on_googleplus']) : 'yes';
			
			$opts_array['social_share_logo_url']   = (isset($_POST['social_share_logo_url'])) ? sanitize_text_field($_POST['social_share_logo_url']) : '';
			
			$opts_array['allow_sharing_on_email']   = (isset($_POST['allow_sharing_on_email'])) ? sanitize_text_field($_POST['allow_sharing_on_email']) : 'yes';
			$opts_array['social_share_email_subject_text']   = (isset($_POST['social_share_email_subject_text'])) ? sanitize_text_field($_POST['social_share_email_subject_text']) : 'Text for email subject';	
			$opts_array['social_share_email_body_text']   = (isset($_POST['social_share_email_body_text'])) ? sanitize_text_field($_POST['social_share_email_body_text']) : 'Text for email body message';	

			
			//if we have an image as tab header , get image size
			if($opts_array['wishlist_slider_tab_image']!='' && $opts_array['wishlist_use_text_or_image_for_slideout_tab']=='image' ){
				//save image width,height
				$image_url = getimagesize($opts_array['wishlist_slider_tab_image']);
				$opts_array['image_handler_width']   = $image_url[0];
				$opts_array['image_handler_height']  = $image_url[1];
			}

			//update option 
			update_option('gema75_wc_wl_saved_admin_options',$opts_array);

			//print_r(get_option('gema75_wc_wl_saved_admin_options',true));
			//die();
			
		}	

		
		/*
		*  adds default plugin admin options 	
		*/
		static function add_default_options_first_time() {

		    $opts = array(
		    		'show_link_on_single_page' 						=> 'yes',
		    		'show_link_on_shop_page' 						=> 'yes',
					'wishlist_position'								=> 'bottom',
					'open_wishlist_when'							=> 'click',
		    		'wishlist_bg_color'								=> '#dd3333',
		    		'wishlist_slider_tab_header'					=> 'Wishlist',
		    		'add_to_wishlist_text'							=> 'Add to wishlist',
		    		'added_to_wishlist_text'						=> 'Added to wishlist',
		    		'already_on_wishlist_text'						=> 'Already on wishlist',
		    		'remove_from_wishlist_text'						=> 'Remove',
		    		'remove_all_from_wishlist_text'					=> 'Remove all',
		    		'add_to_cart_text'								=> 'Add to cart',
		    		'wishlist_slider_tab_image'						=> '',
		    		'wishlist_use_text_or_image_for_slideout_tab'	=> 'text',
					'wishlist_panel_width_in_percent'				=> '80',
					'wishlist_panel_margin_in_percent'				=> '5',
		    		'wishlist_slider_tab_header_show_counter'		=> 'yes',
		    		
					'allow_sharing_on_facebook'						=> 'yes',
					'social_share_facebook_text'					=> 'Facebook share text description',
		    		
					'allow_sharing_on_twitter'						=> 'yes',
		    		'social_share_twitter_text'						=> 'Look what i found for twitter',
						
					'allow_sharing_on_pinterest'					=> 'yes',
					'social_share_pinterest_text'					=> 'Text for pinterest',
					
					'allow_sharing_on_googleplus'					=> 'yes',
					
					'social_share_logo_url'							=> '',
					
					'allow_sharing_on_email'						=> 'yes',
					'social_share_email_subject_text'				=> 'Text for email subject',		
					'social_share_email_body_text'					=> 'Text for email message body',		
		
	
		
		    		'first_time_installation'						=> 'no' //mark as installed
		    		);

			update_option('gema75_wc_wl_saved_admin_options', $opts);
			
			flush_rewrite_rules();
		}
		
		
		/*
		*	Check if Woocommerce is active
		*/
		function is_wc_active(){	

			if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

				//add admin notice ... no WC active
				add_action( 'admin_notices', array($this,'no_wc_active_message' ));

			} else{

				$this->wc_active = true;

				//get saved options for admin 
				$this->get_admin_saved_options();

				//footer scripts
				add_action('wp_footer',array($this,'append_container_on_footer'));
				add_action('wp_footer',array($this,'enqueue_scripts_and_styles'));
			}

		}


		/*
		*	Admin message if woocommerce isnt active
		*/
		function no_wc_active_message(){

			$no_wc_active = '<div class="updated">
					<p>Wishlist plugin is activated but Woocommerce is not active</p>
					</div>';
			echo $no_wc_active;

		}

		
		/*
		*	Append the main wishlist container on the footer 
		*/
		public function append_container_on_footer(){ 
			global $wp_query, $wp_rewrite;

			
			
			//show image or text for the slideout tab
			if($this->wishlist_use_text_or_image_for_slideout_tab === 'image' && $this->wishlist_slider_tab_image != ''){
				$slideout_tab_content =  '<img src="'.$this->wishlist_slider_tab_image.'">'; 
			}else{
				$slideout_tab_content =  $this->wishlist_slider_tab_header; 
			}
			
			//slideout tab counter
			if($this->wishlist_slider_tab_header_show_counter==='yes'){ 
				$tab_counter= '<span id="gema75_wc_wc_count_badge"></span>';
			}else{
				$tab_counter='';
			} 
					
			$slideout_variables_array=array(
											'slideout_tab_header' => $slideout_tab_content,	
											'slideout_tab_counter' => $tab_counter,	
											'slideout_remove_all_text' => $this->remove_all_from_wishlist_text,	
											);
					
			//locate slideout header template
			wc_get_template( 'slideout_header.php', array('slideout_variables' => $slideout_variables_array), 'gema75_wc_wishlist', untrailingslashit( $this->locate_slideout_template('slideout_header.php') ).'/' );
					
					
			if(is_user_logged_in()){ 
		
				$wishlist_social_share_array = array();
				
				$wishlist_social_share_array['wishlist_url'] = $this->get_wishlist_social_url();
				
			
				if($this->allow_sharing_on_facebook==='yes'){

					$wishlist_social_share_array['facebook_link'] = 'https://www.facebook.com/sharer/sharer.php?u='.$wishlist_social_share_array['wishlist_url'];
					$wishlist_social_share_array['facebook_icon'] = $this->locate_social_share_icons('facebook');
				}
				
				if($this->allow_sharing_on_twitter==='yes'){

					$wishlist_social_share_array['twitter_link'] = 'https://twitter.com/share?url='.$wishlist_social_share_array['wishlist_url'].'&amp;text='.$this->social_share_twitter_text;
					$wishlist_social_share_array['twitter_icon'] = $this->locate_social_share_icons('twitter');
				}
				
				if($this->allow_sharing_on_pinterest==='yes'){

					$wishlist_social_share_array['pinterest_link'] = 'https://pinterest.com/pin/create/button/?url='.$wishlist_social_share_array['wishlist_url'].'&amp;media='.$this->social_share_logo_url.'&description='.$this->social_share_pinterest_text;
					$wishlist_social_share_array['pinterest_icon'] = $this->locate_social_share_icons('pinterest');
				}	
				
				if($this->allow_sharing_on_googleplus==='yes'){

					$wishlist_social_share_array['googleplus_link'] = 'https://plus.google.com/share?url='.$wishlist_social_share_array['wishlist_url'];
					$wishlist_social_share_array['googleplus_icon'] = $this->locate_social_share_icons('googleplus');
				}	

				if($this->allow_sharing_on_email==='yes'){

					$wishlist_social_share_array['email_link'] = 'mailto:?Subject='.$this->social_share_email_subject_text.'&amp;Body='.$this->social_share_email_body_text . ' '. $wishlist_social_share_array['wishlist_url'];
					$wishlist_social_share_array['email_icon'] = $this->locate_social_share_icons('email');
				}							

				//locate social share template
				wc_get_template( 'share_buttons.php', array('social_links' => $wishlist_social_share_array ), 'gema75_wc_wishlist', untrailingslashit( $this->locate_slideout_template('share_buttons.php') ).'/' );
			
			} //end if user is loggedin  

			//locate slideout footer template
			wc_get_template( 'slideout_footer.php', array(), 'gema75_wc_wishlist', untrailingslashit( $this->locate_slideout_template('slideout_footer.php') ).'/' );
			
			echo '<style>
				body div.slide-out-div , body div.slide-out-div.open{
					width:'. (int) $this->wishlist_panel_width_in_percent .'%;
					margin: 0px '. (int) $this->wishlist_panel_margin_in_percent .'%;
					}
			</style>';
		
		} 	

		
		/*
		*	Returns the URL for social sharing depending on permalink structure
		*/
		public function get_wishlist_social_url(){
			
			global $wp_query, $wp_rewrite;
			
			//check if using pretty permalinks or not
			if ($wp_rewrite->using_permalinks()) {	
			
				$url = get_bloginfo('url').'/wcwlsoc/'.get_current_user_id().'/';
				
			}else{
			
				$url  = get_bloginfo('url').'/?wcwlsoc&userid='.get_current_user_id();
				
			}
			
			return urlencode($url);
			
		}
		

		/*
		*  Prepares and returns the URL to be added to OG:URL depending on the shared URL and permalink structure
		*/
		public function prepare_og_meta_url(){
			    
				global $wp_query, $wp_rewrite;
 
				//check if using pretty permalinks or not
				if ($wp_rewrite->using_permalinks()) { 		 
				
					$user_id = $wp_query->query_vars['userid'];
					$url = get_bloginfo('url').'/wcwlsoc/'.$user_id.'/';
			 
				} else {
			 
					$user_id = $_GET['userid'];
					$url  = get_bloginfo('url').'/?wcwlsoc&userid='.$user_id;
				}
				
				return $url;
		}

		
		
		/*
		*  Add rewrite rule for social sharing
		*/
		function social_rewrite_rules() {
		
			global $wp;
		
			$wp->add_query_var( 'wcwlsoc' );
			
			$wp->add_query_var( 'userid' );
			
			add_rewrite_rule('wcwlsoc/([^/]*)/?','index.php?wcwlsoc&userid=$matches[1]','top');
			
		}

		
		/*
		*  Redirect to our social share templates
		*/
		public function my_url_handler(){
		
			global $wp_query;

			if (isset($wp_query->query_vars['wcwlsoc']) ) {

				//check if we are overriding from the theme folder
				if (file_exists(TEMPLATEPATH . '/wishlist_templates/wishlist_share.php')){
					$return_template = TEMPLATEPATH . '/wishlist_templates/wishlist_share.php';
				}
				else {
					//no overridings. use the templates from plugin folder
					$return_template = GEMA75_WC_WISHLIST_PLUGIN_DIR . '/wishlist_templates/wishlist_share.php';
				}
				
				
				include($return_template);
				
				die();
			
			}
		

		}
		
		
		/*
		*	Locate slideout template in theme folder or plugin folder
		*/
		public function locate_slideout_template($file){

				//check if we are overriding from the theme folder
				if (file_exists(TEMPLATEPATH . '/wishlist_templates/'.$file)){
					$return_template = TEMPLATEPATH .'/wishlist_templates/';
				}
				else {
					//no overridings. use the templates from plugin folder
					$return_template = GEMA75_WC_WISHLIST_PLUGIN_DIR . '/wishlist_templates/';
				}
				
				
				return $return_template;
			
		}
		

		
		
		/*
		*  Return the social share icons found on theme-s plugin override folder or plugin original folder
		*/
		private function locate_social_share_icons($what_network){
		
				if (file_exists(TEMPLATEPATH. '/wishlist_templates/social_icons/'.$what_network.'.png')){
				
					$return_icon = get_stylesheet_directory_uri() . '/wishlist_templates/social_icons/'.$what_network.'.png';
					
				}else {
				
					//no overridings. use the images from plugin folder
					$return_icon = GEMA75_WC_WISHLIST_PLUGIN_URL . '/wishlist_templates/social_icons/'.$what_network.'.png';
					
				}
	
				return $return_icon;	
		}

	
		
	} //end class Gema75_Woocommerce_Wishlist

	



} //end if class exists Gema75_Woocommerce_Wishlist


$GLOBALS['gema75_wc_wishlist'] = new Gema75_Woocommerce_Wishlist();

if($GLOBALS['gema75_wc_wishlist']->wc_active){ 
	
	require_once( GEMA75_WC_WISHLIST_PLUGIN_DIR . 'wishlist.frontend.class.php');
}


//print_r($gema75_wc_wishlist );
//unset($gema75_wc_wishlist);