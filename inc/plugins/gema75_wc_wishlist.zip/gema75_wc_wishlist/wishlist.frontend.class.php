<?php

if (!class_exists('Gema75_Woocommerce_Wishlist_Frontend_User') && class_exists('Gema75_Woocommerce_Wishlist')) {

	class Gema75_Woocommerce_Wishlist_Frontend_User {
	
		//holds all products in wishlist as an array
		public $wishlist_product_array = array();
	
	
		function __construct(){
			global $gema75_wc_wishlist;
			
			if ( !session_id() ){ session_start(); }
			
			
			
			if($gema75_wc_wishlist->wc_active){
					
				//category product hook  ... below ADD TO CART button
				if($gema75_wc_wishlist->show_link_on_shop_page==='yes' ){
					add_action( 'woocommerce_after_shop_loop_item', array($this,'shop_page_hooks') , 30 ); 
				}
				
				//single product hook ... below ADD TO CART button
				if($gema75_wc_wishlist->show_link_on_single_page ==='yes'){
					add_action( 'woocommerce_after_add_to_cart_form', array($this,'single_product_page_hooks') , 30 ); 
				}					
				
				//add ajax function to add remove from wishlist
				add_action( 'wp_ajax_maybe_add_to_wishlist_ajax', array( $this, 'maybe_add_to_wishlist_ajax'));
				add_action( 'wp_ajax_nopriv_maybe_add_to_wishlist_ajax', array( $this, 'maybe_add_to_wishlist_ajax' ));
				
				//add ajax function to remove a product from wishlist
				add_action( 'wp_ajax_remove_product_from_wishlist_ajax', array( $this, 'remove_product_from_wishlist_ajax'));
				add_action( 'wp_ajax_nopriv_remove_product_from_wishlist_ajax', array( $this, 'remove_product_from_wishlist_ajax' ));
				
				
				//add ajax function to remove all products from wishlist
				add_action( 'wp_ajax_remove_all_products_from_wishlist_ajax', array( $this, 'remove_all_products_from_wishlist_ajax'));
				add_action( 'wp_ajax_nopriv_remove_all_products_from_wishlist_ajax', array( $this, 'remove_all_products_from_wishlist_ajax' ));
				
				//add ajax function to get the wishlist
				add_action( 'wp_ajax_get_wishlist_ajax', array( $this, 'get_wishlist_ajax'));
				add_action( 'wp_ajax_nopriv_get_wishlist_ajax', array( $this, 'get_wishlist_ajax' ));
				
				//add ajax to save wishlist for logged in users if they click "save wishlist"
				add_action( 'wp_ajax_save_wishlist_ajax_for_logged_in_users', array( $this, 'save_wishlist_ajax_for_logged_in_users'));
				add_action( 'wp_ajax_nopriv_save_wishlist_ajax_for_logged_in_users', array( $this, 'save_wishlist_ajax_for_logged_in_users' ));
				
				
				
			}
		}
		
		

		//shows "add to wishlist" link/button on shop page
		function shop_page_hooks(){
			global $post ,$gema75_wc_wishlist ;

			//if logged in 
			if(is_user_logged_in()){
				
					$current_user_id = get_current_user_id();
					
					$current_user_wishlist = get_option('gema75_wishlist_for_user_id_'.$current_user_id);
					
					if(isset($current_user_wishlist['product_in_wishlist'][$post->ID])){
					
						echo  apply_filters( 'gema75_wc_wl_filter_already_on_wishlist', '<span class="gema75_wc_wl_already_on_wishlist"> '. $gema75_wc_wishlist->already_on_wishlist_text .' </span>' );
					
					}else{

						echo '<p><a href="#" class="addToWishlistButton" data-wishlist-id="'.$post->ID.'">'.apply_filters( 'gema75_wc_wl_filter_add_to_wishlist',$gema75_wc_wishlist->add_to_wishlist_text).'</a></p>';
						
					}

			}else{

				if(!isset($_SESSION['gema75_wc_wl_product_array'][$post->ID])){
				
					echo '<p><a href="#" class="addToWishlistButton" data-wishlist-id="'.$post->ID.'">'.apply_filters( 'gema75_wc_wl_filter_add_to_wishlist',$gema75_wc_wishlist->add_to_wishlist_text).'</a></p>';
				
				}else {
				
					echo  apply_filters( 'gema75_wc_wl_filter_already_on_wishlist', '<span class="gema75_wc_wl_already_on_wishlist"> '. $gema75_wc_wishlist->already_on_wishlist_text .' </span>' );
				}
			
			}
		}
		
		

		//shows "add to wishlist" link/button on single product page
		function single_product_page_hooks(){
		
			global $post , $gema75_wc_wishlist ;
			
				//if logged in 
				if(is_user_logged_in()){
				
					$current_user_id = get_current_user_id();
					
					$current_user_wishlist = get_option('gema75_wishlist_for_user_id_'.$current_user_id);
					
					if(isset($current_user_wishlist['product_in_wishlist'][$post->ID])){
					
						
						echo  apply_filters( 'gema75_wc_wl_filter_already_on_wishlist', '<span class="gema75_wc_wl_already_on_wishlist"> '. $gema75_wc_wishlist->already_on_wishlist_text .' </span>' );
					
					}else{

						echo '<p><a href="#" class="addToWishlistButton" data-wishlist-id="'.$post->ID.'">'.apply_filters( 'gema75_wc_wl_filter_add_to_wishlist',$gema75_wc_wishlist->add_to_wishlist_text).'</a></p>';
						
					}

				}else{
		
					//check if product is already in wishlist
					if(!isset($_SESSION['gema75_wc_wl_product_array'][$post->ID])){
					
						echo '<p><a href="#" class="addToWishlistButton" data-wishlist-id="'.$post->ID.'">'.apply_filters( 'gema75_wc_wl_filter_add_to_wishlist',$gema75_wc_wishlist->add_to_wishlist_text).'</a></p>';
						
					}else {
					
						echo  apply_filters( 'gema75_wc_wl_filter_already_on_wishlist', '<span class="gema75_wc_wl_already_on_wishlist"> '. $gema75_wc_wishlist->already_on_wishlist_text .' </span>' );
						
					}
			
				}
			
		}

		
		
		/*
		*  Ajax endpoint when clicking "add to cart" text
		*/
		function maybe_add_to_wishlist_ajax(){

				global $woocommerce;
			
				$id = (int) $_POST['product'];

				$produkti = get_product($id);
				
				$product_array = array(
					'id'			=> $id,
					'price' 		=> $produkti->get_price_html(),
					'title' 		=> $produkti->get_title(),
					'image'			=> $produkti->get_image(),
					'product_type'	=> $produkti->product_type ,
					'permalink' 	=> get_permalink($id),
					
				);
				

				//if logged in , save wishlist  as option
				if(is_user_logged_in()){
				
					$current_user_id = get_current_user_id();
					
					$current_user_wishlist = get_option('gema75_wishlist_for_user_id_'.$current_user_id);
					
					if(isset($current_user_wishlist['product_in_wishlist'][$id])){
					
						die(json_encode("productAlreadyInWishlist"));
					
					}else{

						$current_user_wishlist['product_in_wishlist'][$id]=$product_array;
						
					}

					update_option('gema75_wishlist_for_user_id_'.$current_user_id ,$current_user_wishlist );

					die(json_encode($product_array));
					
				}else {
					//non logged in user
					
					//check if product is already on the wishlist 
					if(isset($_SESSION['gema75_wc_wl_product_array'][$id])){
					
						die(json_encode("productAlreadyInWishlist"));
						
					}
					

					//save the product on the session variable
					$_SESSION['gema75_wc_wl_product_array'][$id]=$product_array;
					
					$this->wishlist_product_array[$id] = $product_array;
					
					die(json_encode($product_array));
					
					
				}
				
				
				

			}



		/*
		*  Returns products in wishlist
		*/
		public function get_wishlist_ajax(){
			
			
			//check if the loggedin user has a saved wishlist 
			if(is_user_logged_in()){
			
				$current_user_id = get_current_user_id();
				
				$current_user_wishlist = get_option('gema75_wishlist_for_user_id_'.$current_user_id);
				
				if(isset($current_user_wishlist['product_in_wishlist']) && count($current_user_wishlist['product_in_wishlist'])>=1 ){
					
					$response = array();
					$response['products_in_wishlist'] = $current_user_wishlist['product_in_wishlist'];
					
					die(json_encode($response));
					
				}else {
					
					die(json_encode('Your wishlist is empty'));
					
				}
				
			}else{
			
			
				if( isset($_SESSION['gema75_wc_wl_product_array']) && count($_SESSION['gema75_wc_wl_product_array'])>=1){

					$response = array();
					$response['products_in_wishlist'] = $_SESSION['gema75_wc_wl_product_array'];
					die(json_encode($response));
					
				} else {
					//print_r($_SESSION['gema75_wc_wl_product_array']);
					die(json_encode('Your wishlist is empty'));
				}
				
				
			}
			
			
		}	
		

		/*
		*  Removes a product from wishlist
		*/
		public function remove_product_from_wishlist_ajax(){
			
			$id = (int) $_POST['product'];
		
			//check if the loggedin user has a saved wishlist 
			if(is_user_logged_in()){
				
				$current_user_id = get_current_user_id();
				
				$current_user_wishlist = get_option('gema75_wishlist_for_user_id_'.$current_user_id);
				
				if(isset($current_user_wishlist['product_in_wishlist'][$id])){
					
					unset($current_user_wishlist['product_in_wishlist'][$id]);
					
					update_option('gema75_wishlist_for_user_id_'.$current_user_id ,$current_user_wishlist );
					
					die(json_encode($current_user_wishlist['product_in_wishlist']));
				
				}else{
				
					die(json_encode('Your wishlist is empty'));
					
				}
				
			}else {
			
				if(count($_SESSION['gema75_wc_wl_product_array'])>=1){
				
					$response = array();
				
					if(isset($_SESSION['gema75_wc_wl_product_array'][$id])){
						
						unset($_SESSION['gema75_wc_wl_product_array'][$id]);
						
						$this->wishlist_product_array = $_SESSION['gema75_wc_wl_product_array'];	
						
						$response['products_in_wishlist'] = $_SESSION['gema75_wc_wl_product_array'];

					}	
					
					die(json_encode($response));
					
				} else {
					
					die(json_encode('Your wishlist is empty'));
				
				}
				
			}
			
			
		}



		/*
		*  Removes all products from wishlist
		*/
		public function remove_all_products_from_wishlist_ajax(){
			
			//check if the loggedin user has a saved wishlist 
			if(is_user_logged_in()){
			
				$current_user_id = get_current_user_id();
			
				delete_option('gema75_wishlist_for_user_id_'.$current_user_id);
				
				$response = array();
				$response['products_in_wishlist']=array();
				die(json_encode($response));
			
			}else{		
			
				if(isset($_SESSION['gema75_wc_wl_product_array']) && count($_SESSION['gema75_wc_wl_product_array'])>=1){
				
					$response = array();

						unset($_SESSION['gema75_wc_wl_product_array']);
						$this->wishlist_product_array = array();	
						$response['products_in_wishlist'] = $this->wishlist_product_array;

					die(json_encode($response));
					
				} else {
					//print_r($_SESSION['gema75_wc_wl_product_array']);
					die(json_encode('Your wishlist was empty'));
				
				}
			
			}
			
			
			
		}
		

	
		/*
		*   og:meta for Facebook and Pinterest
		*/
		public function get_og_meta(){
			
			global $gema75_wc_wishlist;
		
			echo '<!-- OGMETA by Gema75 Woocommerce Wishlist plugin start --> ' . PHP_EOL;
			echo '<meta property="og:title" content="'. wp_title( '|', false, 'right' ) . '"/>' . PHP_EOL;
			echo '<meta property="og:site_name" content="'. get_bloginfo('name').'" />' . PHP_EOL;
			echo '<meta property="og:url" content="' . $gema75_wc_wishlist->prepare_og_meta_url() . '"/>' . PHP_EOL;
			echo '<meta property="og:description" content="'.$gema75_wc_wishlist->social_share_facebook_text.'"/>' . PHP_EOL;
			
			if($gema75_wc_wishlist->social_share_logo_url!=''){
				echo '<meta property="og:image" content="'.$gema75_wc_wishlist->social_share_logo_url.'" />' . PHP_EOL;
			}
			
			echo '<!-- OGMETA by Gema75 Woocommerce Wishlist plugin ends --> ' . PHP_EOL;
			
		}

		/*
		*	Inserts og:meta for Facebook and Pinterest
		*/
		public function insert_og_meta_in_head(){
		
			add_action( 'wp_head', array($this,'get_og_meta'), 5 );
			
		}		
		
				
		
		
	} // end class Gema75_Woocommerce_Wishlist_Frontend_User
	
} //end if class exists Gema75_Woocommerce_Wishlist_Frontend_User	

$gema75_wc_wl_frontend =  new Gema75_Woocommerce_Wishlist_Frontend_User();