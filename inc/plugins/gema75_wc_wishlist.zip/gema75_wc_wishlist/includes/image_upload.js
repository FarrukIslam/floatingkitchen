jQuery(document).ready(function($) {

	//Check if the input text field for the image has value and update the preview image box
	if($('#wishlist_slider_tab_image').val()!=''){
		 $('#wishlist_slider_tab_image_preview').html('<p><img  src="' + $('#wishlist_slider_tab_image').val() + '"><div class="previewImageUploadedRemove"  style="color:#ff0000;cursor: pointer;font-size: 14px;"> <span class="dashicons dashicons-dismiss"  ></span>Remove</div></p>');
	}

	var formfield = null;

	$('#wishlist_slider_tab_image_button').click(function() {
		$('html').addClass('Image');
		formfield = $('#wishlist_slider_tab_image').attr('name');
		tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
		return false;
	});

	window.original_send_to_editor = window.send_to_editor;

	window.send_to_editor = function(html){

		var fileurl;

		if (formfield != null) {
			fileurl = $('img',html).attr('src');
			$('#wishlist_slider_tab_image').val(fileurl);

			var  htmlForPreviewImageUploadedDiv ='<img  src="' + fileurl + '">';
			htmlForPreviewImageUploadedDiv+='<div class="previewImageUploadedRemove"  style="color:#ff0000;cursor: pointer;font-size: 14px;"> <span class="dashicons dashicons-dismiss"  ></span>Remove</div>';
		
			$('#wishlist_slider_tab_image_preview').html(htmlForPreviewImageUploadedDiv);
		
			$('.previewImageUploadedRemove').click(function(){
				$('#wishlist_slider_tab_image_preview').html('');
				$('#wishlist_slider_tab_image').val('');
			
			});

			tb_remove();
			$('html').removeClass('Image');
			formfield = null;
			
		} else {
			window.original_send_to_editor(html);
		}
		
	};


	$('.previewImageUploadedRemove').click(function(){
		$('#wishlist_slider_tab_image_preview').html('');
		$('#wishlist_slider_tab_image').val('');
		
	});


});