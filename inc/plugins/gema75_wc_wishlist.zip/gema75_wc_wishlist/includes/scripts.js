
(function($){



//ADD PRODUCT TO WISHLIST
	jQuery('.addToWishlistButton').click(function(e){
		
		e.preventDefault();
		
		var productID = jQuery(this).attr('data-wishlist-id');
		
		
		jQuery.ajax({
		  type: 'POST',
		  url: woocommerce_params.ajax_url,
		  data: {
			action: 'maybe_add_to_wishlist_ajax',
			product:  productID
		  },
		  dataType: "json",
		  success: function(response, textStatus, XMLHttpRequest){
			//console.log(response);
			
			//check response 
			if(response==='productAlreadyInWishlist'){
			
				console.log('Already Exists in Wishlist');
				
				jQuery('.addToWishlistButton[data-wishlist-id="'+ productID +'"]').append('<span class="alreadyExists">' + gema75_wc_wl_js_strings.AlreadyExists + '</span>');
				
				
				
			}else{
			
				//add the product as a LI child of the UL
				var newWishListHtml = '<div> <div class="gema75_wc_wl_image">' + response.image + '</div> <a href="'+response.permalink+'"> ' + response.title + '</a><p>'+ response.price +'</p>  <a class="add_to_cart_button product_type_simple ajax_add_to_cart" data-product_id="'+ productID +'">' + gema75_wc_wl_js_strings.addToCart + '</a>     <a href="#" class="removeFromWishlistButton" data-wishlist-id="' + productID + '" >' + gema75_wc_wl_js_strings.removeFromWishlist + '</a>  </div>';
				
				
				//add new product to the slider
				 jQuery("#gema75_wishlist_list").data('owlCarousel').addItem(newWishListHtml);
				 
				//replace "add to wishlist" with "added to wishlist"
				jQuery('.addToWishlistButton[data-wishlist-id="'+ productID +'"]').html(gema75_wc_wl_js_strings.addedToWishlist);
				//change the class
				jQuery('.addToWishlistButton[data-wishlist-id="'+ productID +'"]').addClass('addedToWishlistButton');
				jQuery('.addToWishlistButton[data-wishlist-id="'+ productID +'"]').removeClass('addToWishlistButton');
				
				//show the "remove all" link
				hide_or_show_remove_all_link();
			 }
			
		  },
		  error: function(MLHttpRequest, textStatus, errorThrown){
			console.log(errorThrown);
		  }
		});		
		

	});


//GET PRODUCT FROM WISHLIST
	jQuery.ajax({
		  type: 'POST',
		  url: woocommerce_params.ajax_url,
		  data: {
			action: 'get_wishlist_ajax',
		  },
		  dataType: "json",
		  success: function(response, textStatus, XMLHttpRequest){

			//console.log(response);
			
			var newWishListHtml ='';
			
			for (var k in response.products_in_wishlist){
				
				// console.log("Key is " + k + ", value is" + response.products_in_wishlist[k]);
				console.log('produkti eshte ' + response.products_in_wishlist[k].product_type);
				

				
				//add the product as a LI child of the UL
				newWishListHtml =  '<div> <div class="gema75_wc_wl_image">' + response.products_in_wishlist[k].image + '</div> <a href="'+response.products_in_wishlist[k].permalink+'"> ' + response.products_in_wishlist[k].title + '</a><p>'+ response.products_in_wishlist[k].price +'</p>';

				
				//check if we have a variable product 
				if(response.products_in_wishlist[k].product_type=='variable'){
					newWishListHtml += '<a href="'+response.products_in_wishlist[k].permalink+'"> Select options </a> <br>'; 
				}
				
				if(response.products_in_wishlist[k].product_type=='simple'){
					newWishListHtml += '<a class="add_to_cart_button product_type_simple ajax_add_to_cart" data-product_id="'+ response.products_in_wishlist[k].id +'">' + gema75_wc_wl_js_strings.addToCart + '</a> '; 
				}
				
				
				newWishListHtml += '<a class="removeFromWishlistButton" data-wishlist-id="' + response.products_in_wishlist[k].id + '" >' + gema75_wc_wl_js_strings.removeFromWishlist + '</a> </div>';

				
				//refresh the slider
				jQuery("#gema75_wishlist_list").data('owlCarousel').addItem(newWishListHtml);	
			
				//reset
				newWishListHtml ='';
				
			}

			hide_or_show_remove_all_link();

		  },
		  error: function(MLHttpRequest, textStatus, errorThrown){
			console.log(errorThrown);
		  }
	});		

	
	

//REMOVE SINGLE PRODUCT FROM WISHLIST	

	jQuery("body").on("click",".removeFromWishlistButton",function(e) {
		//console.log('hallall');

		e.preventDefault();
		
		var productID = jQuery(this).attr('data-wishlist-id');
		
		var elementiMeIndex = jQuery(this).parent().parent().index();
		
		jQuery.ajax({
		  type: 'POST',
		  url: woocommerce_params.ajax_url,
		  data: {
			action: 'remove_product_from_wishlist_ajax',
			product:  productID
		  },
		  dataType: "json",
		  success: function(response, textStatus, XMLHttpRequest){
			console.log(response);

			//remove item from owl carousel
			jQuery("#gema75_wishlist_list").data('owlCarousel').removeItem(elementiMeIndex);
			
			hide_or_show_remove_all_link();
			
		  },
		  error: function(MLHttpRequest, textStatus, errorThrown){
			console.log(errorThrown);
		  }
		});		
		

	});


	
//REMOVE ALL PRODUCTS FROM WISHLIST	

	jQuery("body").on("click",".gema75_removeAllFromWishlistButton",function(e) {
		
		e.preventDefault();

		jQuery.ajax({
		  type: 'POST',
		  url: woocommerce_params.ajax_url,
		  data: {
			action: 'remove_all_products_from_wishlist_ajax'
		  },
		  dataType: "json",
		  success: function(response, textStatus, XMLHttpRequest){
			console.log(response);

			//remove all item from owl carousel
			jQuery("#gema75_wishlist_list div.owl-wrapper-outer div.owl-wrapper div").remove();
			
			//remove the "remove all"
			hide_or_show_remove_all_link();
			
		  },
		  error: function(MLHttpRequest, textStatus, errorThrown){
			console.log(errorThrown);
		  }
		});		
		

	});	
	



	
	//start the carousel
	jQuery("#gema75_wishlist_list").owlCarousel({items : 10,});	

	// OWL Carousel avigation Events
	jQuery('.gema75_wc_wl_owl_next').click(function(){
		jQuery("#gema75_wishlist_list").trigger('owl.next');
	});

	jQuery('.gema75_wc_wl_owl_prev').click(function(){
		jQuery("#gema75_wishlist_list").trigger('owl.prev');
	});

	
	
	
	 /*
	 *  Get how many products are on the wishlist
	 */
	function gema75_how_many_items_in_wishlist(){
		var how_many = jQuery("#gema75_wishlist_list div.owl-wrapper-outer div.owl-wrapper div.owl-item").length;
		console.log('aktualisht jane ' + how_many + ' produkte ne cart');
		return parseInt(how_many);
	}
	
	 /*
	 *  Hide or show the "remove all" link if products in wishlist is >=1
	 */
	function hide_or_show_remove_all_link(){
		if(gema75_how_many_items_in_wishlist()>=1){
			jQuery(".gema75_removeAllFromWishlistButton").show();
		}else{
			jQuery(".gema75_removeAllFromWishlistButton").hide();
		}
		
		gema75_update_badge_count();
	}


	 /*
	 *  Set the badge count on the wishlist tab
	 */
	function gema75_update_badge_count(){
		jQuery("#gema75_wc_wc_count_badge").html(gema75_how_many_items_in_wishlist());
	}	
	
	
	//are we using an image or text for the slideout tab
	if(gema75_wc_wl_js_strings.wishlist_tab_text_or_image=='image'){
		var image_or_text ='image';
	}else{
	
		var image_or_text ='text';
	}
	
	//add the slideout on the page
	jQuery('.slide-out-div').tabSlideOut({
            tabHandle: '.handle',                     //class of the element that will become your tab
			imageOrText: image_or_text,
            pathToTabImage: '' + gema75_wc_wl_js_strings.slider_tab_image_url + '', //path to the image for the tab //Optionally can be set using css
            imageHeight: gema75_wc_wl_js_strings.slider_tab_image_height + 'px',                     //height of tab image           //Optionally can be set using css
            imageWidth: gema75_wc_wl_js_strings.slider_tab_image_width + 'px',                       //width of tab image            //Optionally can be set using css
            tabLocation: '' + gema75_wc_wl_js_strings.position +'',                      //side of screen where tab lives, top, right, bottom, or left
            speed: 300,                               //speed of animation
            action:  '' + gema75_wc_wl_js_strings.open_wishlist_with +'',                          //options: 'click' or 'hover', action to trigger animation
            topPos: '200px',                          //position from the top/ use if tabLocation is left or right
            leftPos: '20px',                          //position from left/ use if tabLocation is bottom or top
            fixedPosition: true ,                     //options: true makes it stick(fixed position) on scroll
			bgcolor :  '' + gema75_wc_wl_js_strings.wishlist_bg_color +''
        });	

		
	//CSS from admin options
	jQuery('.slide-out-div').css('background-color', '' + gema75_wc_wl_js_strings.wishlist_bg_color +'');
	
		
})(jQuery);
