<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce, $post , $gema75_wc_wl_frontend;



//add the "woocommerce" class to body so we can use the woocommerce css
add_filter('body_class','gema75_wc_wl_add_body_class');
function gema75_wc_wl_add_body_class($classes) {
	$classes[] = 'woocommerce';
	return $classes;
}


//remove the "add to wishlist" action
remove_action( 'woocommerce_after_shop_loop_item', array( $gema75_wc_wl_frontend, 'shop_page_hooks' ),30 );



//Add the OG:META 
$gema75_wc_wl_frontend->insert_og_meta_in_head();



//show WP header
get_header();





$userid = $wp_query->query_vars['userid'];

$user_wishlist = get_option('gema75_wishlist_for_user_id_'.$userid);

if(isset($user_wishlist['product_in_wishlist']) && count($user_wishlist['product_in_wishlist'])>=1){

	//echo '<div class="wishlist_content" style="width:80%;margin:0 auto">';
	
	woocommerce_output_content_wrapper();
	
	echo  apply_filters( 'woocommerce_page_title', '<H1> Wishlist Products</H1>' );
	
	do_action('woocommerce_before_shop_loop'); 
	
	woocommerce_product_loop_start(); 

	foreach($user_wishlist['product_in_wishlist'] as $single_product){ 
	

		$product_id = absint( $single_product['id'] );

		if ( $product_id ) {

			// Get product 
			$post = get_post( $product_id );

			setup_postdata( $post );
		
			$product = $product_id;
			
			wc_get_template_part( 'content', 'product' ); 
			
			
		}

	}
	
	 woocommerce_product_loop_end();
	
	 do_action('woocommerce_after_shop_loop');
	 
	 woocommerce_output_content_wrapper_end();
	
	

}else{

	echo '<h2> This user doesnt have any item on the wishlist </h2>';

}

?>



<?php
get_footer();
?>