<div class="slide-out-div">
				<a class="handle"><?php echo $slideout_variables['slideout_tab_header'] ;?><?php echo $slideout_variables['slideout_tab_counter'] ;?></a>
				
				<div style="float:right;">
					<a href="#" class="gema75_removeAllFromWishlistButton"><?php echo $slideout_variables['slideout_remove_all_text'] ;?></a> 
				
</div>