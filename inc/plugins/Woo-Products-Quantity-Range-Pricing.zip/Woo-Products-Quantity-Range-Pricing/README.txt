=== Woo Products Quantity Range Pricing ===
Contributors: soniakash
Donate link: akashsoni.com
Tags: Quantity Range Pricing, Quantity Pricing, Products Quantity Range Pricing, Woo Products Pricing
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An easy way to add product quantity range wise price in WooCommerce.

== Description ==

This plugin are use for add quantity range wise set pricing in WooCommerce product.

  	1 ) Quick and easy installation.
	2 ) Multiple quantity range price set in simple & variation product.
			2.1 ) Three type price you can set in product.
			2.2 ) Percentage discount
			2.3 ) Price discount
	3 ) Selling price
	4 ) Two type quantity range you can set in product price.
			4.1 ) Between quantity range set price ( 10 – 15 )
			4.2 ) Minimum quantity or range set price ( 50 or more )
	5 ) Full plugin enable / disable facility option.
	6 ) Product wise enable / disable facility option.
	7 ) Front-end show quantity range price list on product detail page.
	8 ) Set front-end quantity price style options.

== Installation ==

1. Upload `woo-products-quantity-range-pricing .php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place `<?php do_action('plugin_name_hook'); ?>` in your templates
4. Go to plugin setting page and click Enable Product Quantity Range Pricing facility button and click save button for active plugin facility.
5. Go to product edit page and Enable Product Quantity Range Pricing facility in general tab.
6. After click enable button you can see quantity range wise pricing set table fields. You can set your pricing range and save product.

== Frequently Asked Questions ==
*
= A question that someone might have =
*

= What about foo bar? =
*

== Screenshots ==
*
== Changelog ==
*

== Upgrade Notice ==
*


`<?php code(); // goes in backticks ?>`