<?php
/**
 * Admin quantity wish pricing fronted table.
 *
 * @link       akashsoni.com
 * @since      1.0.0
 *
 * @package    Woo_Products_Quantity_Range_Pricing
 * @subpackage Woo_Products_Quantity_Range_Pricing/public/partials
 */

?>
<table class='variation_quantity_table'>
	<thead>
	<tr>
		<th><?php echo $heading_quantity; ?></th>
		<th><?php echo $heading_price; ?></th>
	</tr>
	</thead>
	<tbody>
	<?php
	$as_quantity_rage_values = Woo_Products_Quantity_Range_Pricing_Admin::woo_quantity_value_sorting_by_order( $as_quantity_rage_values );
	// Display all quantity price values in table.
	foreach ( $as_quantity_rage_values as $as_quantity_rage_value ) {


		if ( ! empty( $as_quantity_rage_value['min_qty'] ) && $as_quantity_rage_value['max_qty'] && $as_quantity_rage_value['price'] ) {

			$type  = $as_quantity_rage_value['type'];
			$price = $as_quantity_rage_value['price']; ?>
			<tr>
				<td>
					<?php
					echo esc_attr( $as_quantity_rage_value['min_qty'] );
					if ( $as_quantity_rage_value['max_qty'] == - 1 ) {
						echo ' ' . $label_or_more;
					} else {
						echo esc_attr( ' - ' . $as_quantity_rage_value['max_qty'] );
					}
					?>
				</td>
				<td>

					<?php
					switch ( $type ) {

						case 'percentage':
							$label_discount 		= apply_filters( 'wpqrp_label_discount',  ' Discount ' );
							echo esc_attr( $currency . ( $final_price - ( ( $final_price * $price ) / 100 ) ) . ' ( ' . $price . ' % ' . $label_discount .' )' );
							break;

						case 'price':
							$label_discount 		= apply_filters( 'wpqrp_label_discount',  ' Discount ' );
							echo esc_attr( $currency . ( $final_price - $price ) . ' ( ' . $currency . $price . $label_discount . ' ) ' );
							break;

						case 'fixed':
							$label_selling_pricing 	= apply_filters( 'wpqrp_label_selling_pricing', ' ( Selling price )' );
							echo $currency . $price . $label_selling_pricing;
							break;	

					}
					?>

				</td>
			</tr>

			<?php
		}
	}
	// End foreach.
	?>

	</tbody>
</table>
